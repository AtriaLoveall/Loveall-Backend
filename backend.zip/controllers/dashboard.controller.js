const dashboard = async (req, res, next) => {
    return res.status(200).json({message: "Everything is working fine"});
}

export default dashboard;